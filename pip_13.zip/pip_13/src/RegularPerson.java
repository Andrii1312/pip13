public class RegularPerson {

    public String name;
    public String familyName;

    public RegularPerson (String name, String familyName) {

        this.name = name;
        this.familyName = familyName;


    }

}

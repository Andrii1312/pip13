public class Billionaire {

    public long money;

    public Billionaire (RegularPerson.tony) {

    }

    public void setMoney(long money) {
        this.money = money;
    }
}

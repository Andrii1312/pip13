public class Main {

    public static void main(String[] args) {

        String name = "Tony";
        String familyName = "Stark";
        RegularPerson tony = new RegularPerson (name, familyName);

        Billionaire tonyStark = new Billionaire (tony);
        tonyStark.setMoney (1000000000000l);

        Enemy enemy = new Enemy ("Justin Hammer.");
        enemy.makeEvilIntrodution ();
        enemy.attack(tonyStark);

        if (tonyStark.isInDanger()) {

            IronMan ironMan = new IronMan(tonyStark);
            ironMan.attack(enemy);
            ironMan.printNameOfOwner();

        }

            else {

            tonyStark.goParty ();

            }

        }
    }
import java.util.Random;

public class Enemy {

    public String  name_FamilyName;

    public Enemy (String name_FamilyName) {

        this.name_FamilyName = name_FamilyName;

    }

    public void makeEvilIntrodution() {

        System.out.println("I'm Justin Hammer!");

    }

    public void attack () {

        int i = (int)(1+Math.random()*1);
        switch (i) {

            case 1:
                System.out.println("Justin Hammer attacks Tony Stark!");
                break;
            case 2:
                System.out.println("Justin Hammer missed hit!");
        }

    }

}
